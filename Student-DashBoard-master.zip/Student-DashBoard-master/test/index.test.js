const assert = require('assert');
describe('Application Tests', () => {
    it('hello world!', () => {
        assert.strictEqual(1 + 1, 2);
    });
});